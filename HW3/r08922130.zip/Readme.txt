GD 
SGD

Question 7

Use 0/1 Error as E_in
Question 8

Use 0/1 Error as E_out


